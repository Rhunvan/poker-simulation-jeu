import { REAL_TABLE_POPULATION } from '../../config/tablePopulation'
import type { NumericRange } from '../../config/schema'
import type { BettingStreet, DecisionContext, PlayerCommand } from '../core/types'
import { RANK_TO_VALUE } from '../core/cards'
import { analyzeBoardTexture } from '../eval/boardTexture'
import { evaluateHoldemHand } from '../eval/handEvaluator'
import type { EmotionModifiers } from './emotionModel'

export type DecisionCommandKind = PlayerCommand['kind']

export type DecisionScenario =
  | 'unopened'
  | 'limped-pot'
  | 'facing-open'
  | 'facing-3bet'
  | 'facing-4bet'
  | 'checked-to'
  | 'facing-bet'

export interface PopulationSnapshot {
  street: BettingStreet
  scenario: DecisionScenario
  handStrength: number
  playability: number
  handKey: string
  stackBb: number
  effectiveStackBb: number
  toCallBb: number
  potBb: number
  currentBetBb: number
  limperCount: number
  raiseCount: number
  playersInHand: number
  positionScore: number
  candidateWeights: Record<DecisionCommandKind, number>
  valueIntent: number
  bluffIntent: number
  jamIntent: number
  preferOversize: boolean
  preferOverbet: boolean
  preferNonAllInBigRaise: boolean
  tags: string[]
}

interface PreflopSnapshot {
  strength: number
  playability: number
  handKey: string
  pair: boolean
  suited: boolean
  gap: number
  high: number
  low: number
  broadwayCount: number
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value))
}

function descriptorValue(
  descriptor:
    | 'very_low'
    | 'low'
    | 'low_to_medium_unbalanced'
    | 'medium'
    | 'elevated'
    | 'high'
    | 'rare',
): number {
  switch (descriptor) {
    case 'very_low':
      return 0.08
    case 'low':
      return 0.18
    case 'low_to_medium_unbalanced':
      return 0.28
    case 'medium':
      return 0.42
    case 'elevated':
      return 0.58
    case 'high':
      return 0.74
    case 'rare':
      return 0.05
    default:
      return 0.3
  }
}

export function rangeMid(range: NumericRange): number {
  return (range[0] + range[1]) / 2
}

function roundToHundredth(value: number): number {
  return Math.round(value * 100) / 100
}

function canonicalStartingHand(context: DecisionContext): string {
  const [firstCard, secondCard] = [...context.player.holeCards].sort(
    (left, right) => RANK_TO_VALUE[right.rank] - RANK_TO_VALUE[left.rank],
  )
  const suffix = firstCard.suit === secondCard.suit ? 's' : 'o'
  if (firstCard.rank === secondCard.rank) {
    return `${firstCard.rank}${secondCard.rank}`
  }
  return `${firstCard.rank}${secondCard.rank}${suffix}`
}

function analyzePreflopHand(context: DecisionContext): PreflopSnapshot {
  const [cardA, cardB] = [...context.player.holeCards].sort(
    (left, right) => RANK_TO_VALUE[right.rank] - RANK_TO_VALUE[left.rank],
  )
  const high = RANK_TO_VALUE[cardA.rank]
  const low = RANK_TO_VALUE[cardB.rank]
  const pair = high === low
  const suited = cardA.suit === cardB.suit
  const gap = pair ? 0 : high - low
  const broadwayCount = [high, low].filter((value) => value >= 10).length
  let strength = 0
  let playability = 0

  if (pair) {
    strength = 0.46 + high / 24
    playability = 0.24 + high / 28
  } else {
    strength =
      (high >= 14 ? 0.28 : high >= 13 ? 0.24 : high >= 12 ? 0.2 : high >= 11 ? 0.16 : high >= 10 ? 0.12 : 0.06) +
      (low >= 10 ? 0.12 : low >= 8 ? 0.07 : low >= 6 ? 0.04 : 0.01)
    playability =
      (suited ? 0.14 : 0.02) +
      (gap <= 1 ? 0.14 : gap === 2 ? 0.08 : gap === 3 ? 0.03 : -0.02) +
      (broadwayCount === 2 ? 0.11 : 0) +
      (high === 14 && low <= 5 ? 0.09 : 0)

    if (high <= 8 && low <= 5 && !suited && gap >= 3) {
      strength -= 0.08
      playability -= 0.06
    }
  }

  return {
    strength: clamp(roundToHundredth(strength), 0, 1),
    playability: clamp(roundToHundredth(playability), 0, 1),
    handKey: canonicalStartingHand(context),
    pair,
    suited,
    gap,
    high,
    low,
    broadwayCount,
  }
}

function getBigBlind(context: DecisionContext): number {
  return context.state.config.blindSchedule?.[context.state.currentLevelIndex]?.bigBlind ?? context.state.config.bigBlind
}

function getEffectiveStackBb(context: DecisionContext, bb: number): number {
  const actorTotal = context.player.stack + context.player.currentBet
  const opponentTotal = context.playersStillInHand
    .filter((entry) => entry.id !== context.player.id)
    .reduce((best, entry) => Math.min(best, entry.stack + entry.currentBet), actorTotal)
  return Math.max(0, Math.min(actorTotal, opponentTotal) / bb)
}

function getPositionScore(context: DecisionContext): number {
  const activePlayers = context.playersStillInHand
  const behind = activePlayers.filter((entry) => entry.seatIndex > context.player.seatIndex).length
  return behind / Math.max(1, activePlayers.length - 1)
}

function countLimpers(context: DecisionContext, bb: number): number {
  if (context.state.street !== 'preflop' || context.state.fullRaiseCounter > 0) {
    return 0
  }

  return context.state.players.filter((entry) => {
    if (entry.id === context.player.id || entry.hasFolded || entry.holeCards.length === 0) {
      return false
    }
    if (entry.seatIndex === context.state.bigBlindSeatIndex) {
      return false
    }
    return entry.hasActedThisRound && entry.currentBet === bb
  }).length
}

function createWeightRecord(): Record<DecisionCommandKind, number> {
  return {
    fold: 0,
    check: 0,
    call: 0,
    bet: 0,
    raise: 0,
    'all-in': 0,
  }
}

function buildPreflopSnapshot(context: DecisionContext, emotions: EmotionModifiers): PopulationSnapshot {
  const bb = getBigBlind(context)
  const hand = analyzePreflopHand(context)
  const stackBb = (context.player.stack + context.player.currentBet) / bb
  const effectiveStackBb = getEffectiveStackBb(context, bb)
  const toCallBb = context.legalActions.toCall / bb
  const potBb = context.potTotal / bb
  const limperCount = countLimpers(context, bb)
  const raiseCount = context.state.fullRaiseCounter
  const currentBetBb = context.state.currentBet / bb
  const looseEntryBase =
    descriptorValue(REAL_TABLE_POPULATION.averageLimpRate) * 0.22 +
    descriptorValue(REAL_TABLE_POPULATION.averageColdCallRate) * 0.18
  const scenario: DecisionScenario =
    raiseCount === 0 && currentBetBb <= 1
      ? limperCount > 0
        ? 'limped-pot'
        : 'unopened'
      : raiseCount <= 1
        ? 'facing-open'
        : raiseCount === 2
          ? 'facing-3bet'
          : 'facing-4bet'
  const weights = createWeightRecord()
  const positionScore = getPositionScore(context)
  const valueIntent = clamp(hand.strength + hand.playability * 0.22 + positionScore * 0.08, 0, 1.2)
  const bluffIntent = clamp(
    (REAL_TABLE_POPULATION.irrationalAggroPlayersExist ? 0.12 : 0.05) +
      emotions.aggressionBoost * 0.16 -
      emotions.cautionBoost * 0.12,
    0,
    0.45,
  )
  const jamIntent =
    stackBb <= 18
      ? clamp((hand.strength - 0.64) * 1.8 + emotions.shoveBoost * 0.8, 0, 0.55)
      : clamp(emotions.shoveBoost * 0.12, 0, 0.08)

  if (scenario === 'unopened') {
    weights.fold = clamp(0.98 - hand.strength * 1.42 - hand.playability * 0.52 - looseEntryBase, 0.03, 1)
    weights.call = clamp(0.09 + looseEntryBase * 1.35 + hand.playability * 0.62 - hand.strength * 0.22, 0, 1.15)
    weights.raise = clamp((hand.strength - 0.34) * 1.52 + hand.playability * 0.18 + positionScore * 0.1, 0, 1.25)
    weights['all-in'] = jamIntent * 0.1
  } else if (scenario === 'limped-pot') {
    weights.fold = clamp(0.86 - hand.strength * 1.18 - hand.playability * 0.45 - looseEntryBase * 0.5, 0.02, 0.82)
    weights.call = clamp(
      0.24 + looseEntryBase * 1.1 + hand.playability * 0.65 + limperCount * 0.08 - toCallBb * 0.06,
      0,
      1.35,
    )
    weights.raise = clamp((hand.strength - 0.42) * 1.5 + limperCount * 0.08 + emotions.aggressionBoost * 0.12, 0, 1.2)
    weights['all-in'] = jamIntent * 0.08
  } else if (scenario === 'facing-open') {
    weights.fold = clamp(0.88 - hand.strength * 0.82 - hand.playability * 0.3 + toCallBb * 0.06, 0.03, 1.15)
    weights.call = clamp(
      0.12 + hand.playability * 0.62 + looseEntryBase * 0.82 + positionScore * 0.08 - toCallBb * 0.08,
      0,
      1.2,
    )
    weights.raise = clamp((hand.strength - 0.56) * 1.6 + hand.playability * 0.12 + emotions.aggressionBoost * 0.1, 0, 1.05)
    weights['all-in'] = jamIntent * 0.28
  } else if (scenario === 'facing-3bet') {
    weights.fold = clamp(1.02 - hand.strength * 0.92 - hand.playability * 0.16 + toCallBb * 0.05, 0.05, 1.2)
    weights.call = clamp(0.04 + hand.strength * 0.54 + hand.playability * 0.22 - toCallBb * 0.05, 0, 0.95)
    weights.raise = clamp((hand.strength - 0.76) * 1.5 + emotions.aggressionBoost * 0.08, 0, 0.62)
    weights['all-in'] = jamIntent * 0.55
  } else {
    weights.fold = clamp(1.08 - hand.strength * 0.88 + toCallBb * 0.04, 0.08, 1.25)
    weights.call = clamp(0.02 + hand.strength * 0.42 - toCallBb * 0.06, 0, 0.6)
    weights.raise = clamp((hand.strength - 0.84) * 1.35, 0, 0.35)
    weights['all-in'] = jamIntent * 0.72
  }

  return {
    street: 'preflop',
    scenario,
    handStrength: hand.strength,
    playability: hand.playability,
    handKey: hand.handKey,
    stackBb,
    effectiveStackBb,
    toCallBb,
    potBb,
    currentBetBb,
    limperCount,
    raiseCount,
    playersInHand: context.playersStillInHand.length,
    positionScore,
    candidateWeights: weights,
    valueIntent,
    bluffIntent,
    jamIntent,
    preferOversize: hand.strength > 0.55 || emotions.aggressionBoost > 0.16,
    preferOverbet: false,
    preferNonAllInBigRaise: REAL_TABLE_POPULATION.oversizedNonJamRaisesPreferred,
    tags: [
      scenario === 'unopened' ? 'home-game-unopened' : `scenario:${scenario}`,
      limperCount > 0 ? `limpers:${limperCount}` : 'no-limpers-yet',
      hand.pair ? 'pair-starting-hand' : hand.suited ? 'suited-starting-hand' : 'offsuit-starting-hand',
    ],
  }
}

function buildPostflopSnapshot(context: DecisionContext, emotions: EmotionModifiers): PopulationSnapshot {
  const bb = getBigBlind(context)
  const evaluated = evaluateHoldemHand(context.player.holeCards, context.state.board)
  const board = analyzeBoardTexture(context.state.board)
  const stackBb = (context.player.stack + context.player.currentBet) / bb
  const effectiveStackBb = getEffectiveStackBb(context, bb)
  const toCallBb = context.legalActions.toCall / bb
  const potBb = context.potTotal / bb
  const currentBetBb = context.state.currentBet / bb
  const pressure = context.legalActions.toCall / Math.max(1, context.potTotal)
  const drawStrength =
    (evaluated.flushDraw ? 0.16 : 0) +
    (evaluated.openEndedStraightDraw ? 0.14 : 0) +
    (evaluated.gutshotStraightDraw ? 0.07 : 0) +
    (evaluated.comboDraw ? 0.1 : 0)
  const madeStrength =
    evaluated.normalizedStrength +
    (evaluated.pairType === 'overpair' ? 0.18 : 0) +
    (evaluated.pairType === 'top-pair' ? 0.1 : 0) +
    (evaluated.pairType === 'two-pair+' ? 0.12 : 0)
  const handStrength = clamp(madeStrength + drawStrength * 0.55, 0, 1.25)
  const weights = createWeightRecord()
  const bluffPopulation =
    context.state.street === 'river'
      ? descriptorValue(REAL_TABLE_POPULATION.riverBluffPopulation)
      : descriptorValue('medium')
  const valueIntent = clamp(handStrength + emotions.aggressionBoost * 0.08, 0, 1.3)
  const bluffIntent = clamp(
    bluffPopulation * 0.38 +
      board.straightPressure * 0.18 +
      board.flushPressure * 0.12 +
      emotions.aggressionBoost * 0.18 -
      emotions.cautionBoost * 0.15 -
      context.playersStillInHand.length * 0.05,
    0,
    0.72,
  )
  const jamIntent =
    effectiveStackBb <= 16
      ? clamp(valueIntent * 0.25 + drawStrength * 0.12 + emotions.shoveBoost * 0.45, 0, 0.45)
      : clamp(emotions.shoveBoost * 0.08, 0, 0.08)

  if (context.legalActions.toCall === 0) {
    weights.check = clamp(0.62 - valueIntent * 0.24 - bluffIntent * 0.08 + context.playersStillInHand.length * 0.04, 0.08, 1)
    weights.bet = clamp(valueIntent * 0.95 + drawStrength * 0.42 + bluffIntent * 0.44, 0, 1.32)
    weights['all-in'] = jamIntent * 0.25
  } else {
    weights.fold = clamp(0.76 - handStrength * 0.42 - drawStrength * 0.18 + pressure * 0.24, 0.03, 1.05)
    weights.call = clamp(
      0.08 + handStrength * 0.56 + drawStrength * 0.54 + emotions.curiosityBoost * 0.26 - pressure * 0.18,
      0,
      1.3,
    )
    weights.raise = clamp(valueIntent * 0.44 + drawStrength * 0.18 + bluffIntent * 0.16 - context.playersStillInHand.length * 0.05, 0, 0.92)
    weights['all-in'] = jamIntent * (effectiveStackBb <= 10 ? 0.6 : 0.28)
  }

  return {
    street: context.state.street,
    scenario: context.legalActions.toCall === 0 ? 'checked-to' : 'facing-bet',
    handStrength,
    playability: drawStrength,
    handKey: canonicalStartingHand(context),
    stackBb,
    effectiveStackBb,
    toCallBb,
    potBb,
    currentBetBb,
    limperCount: 0,
    raiseCount: context.state.fullRaiseCounter,
    playersInHand: context.playersStillInHand.length,
    positionScore: getPositionScore(context),
    candidateWeights: weights,
    valueIntent,
    bluffIntent,
    jamIntent,
    preferOversize: false,
    preferOverbet: context.state.street !== 'flop' && bluffIntent > 0.24,
    preferNonAllInBigRaise: true,
    tags: [
      context.legalActions.toCall === 0 ? 'checked-to' : 'under-pressure',
      evaluated.category,
      board.paired ? 'paired-board' : 'unpaired-board',
    ],
  }
}

export function buildPopulationSnapshot(
  context: DecisionContext,
  emotions: EmotionModifiers,
): PopulationSnapshot {
  return context.state.street === 'preflop'
    ? buildPreflopSnapshot(context, emotions)
    : buildPostflopSnapshot(context, emotions)
}
