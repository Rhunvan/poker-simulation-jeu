import type { TablePlayer } from './types'

export function isEligibleForNextHand(player: TablePlayer): boolean {
  return !player.isSittingOut && player.stack > 0
}

export function getParticipatingSeats(players: TablePlayer[]): number[] {
  return players
    .filter((player) => isEligibleForNextHand(player))
    .map((player) => player.seatIndex)
    .sort((left, right) => left - right)
}

export function getNextSeat(
  players: TablePlayer[],
  fromSeatIndex: number,
  predicate: (player: TablePlayer) => boolean,
): number {
  const maxSeat = players.length
  for (let offset = 1; offset <= maxSeat; offset += 1) {
    const seatIndex = (fromSeatIndex + offset) % maxSeat
    const player = players.find((entry) => entry.seatIndex === seatIndex)
    if (player && predicate(player)) {
      return seatIndex
    }
  }
  return fromSeatIndex
}

export function resolveBlindAssignments(
  players: TablePlayer[],
  dealerSeatIndex: number,
): {
  dealerSeatIndex: number
  smallBlindSeatIndex: number
  bigBlindSeatIndex: number
  headsUp: boolean
} {
  const participatingSeats = getParticipatingSeats(players)
  if (participatingSeats.length < 2) {
    return {
      dealerSeatIndex,
      smallBlindSeatIndex: dealerSeatIndex,
      bigBlindSeatIndex: dealerSeatIndex,
      headsUp: false,
    }
  }

  const normalizedDealerSeatIndex = participatingSeats.includes(dealerSeatIndex)
    ? dealerSeatIndex
    : getNextSeat(players, dealerSeatIndex, isEligibleForNextHand)

  if (participatingSeats.length === 2) {
    const bigBlindSeatIndex = getNextSeat(
      players,
      normalizedDealerSeatIndex,
      isEligibleForNextHand,
    )
    return {
      dealerSeatIndex: normalizedDealerSeatIndex,
      smallBlindSeatIndex: normalizedDealerSeatIndex,
      bigBlindSeatIndex,
      headsUp: true,
    }
  }

  const smallBlindSeatIndex = getNextSeat(
    players,
    normalizedDealerSeatIndex,
    isEligibleForNextHand,
  )
  const bigBlindSeatIndex = getNextSeat(
    players,
    smallBlindSeatIndex,
    isEligibleForNextHand,
  )

  return {
    dealerSeatIndex: normalizedDealerSeatIndex,
    smallBlindSeatIndex,
    bigBlindSeatIndex,
    headsUp: false,
  }
}

export function getFirstActorPreflop(
  players: TablePlayer[],
  smallBlindSeatIndex: number,
  bigBlindSeatIndex: number,
  headsUp: boolean,
  canAct: (player: TablePlayer) => boolean,
): number | null {
  if (headsUp) {
    const smallBlind = players.find((player) => player.seatIndex === smallBlindSeatIndex)
    return smallBlind && canAct(smallBlind) ? smallBlindSeatIndex : null
  }

  const seatIndex = getNextSeat(players, bigBlindSeatIndex, canAct)
  const player = players.find((entry) => entry.seatIndex === seatIndex)
  return player && canAct(player) ? seatIndex : null
}

export function getFirstActorPostflop(
  players: TablePlayer[],
  dealerSeatIndex: number,
  canAct: (player: TablePlayer) => boolean,
): number | null {
  const seatIndex = getNextSeat(players, dealerSeatIndex, canAct)
  const player = players.find((entry) => entry.seatIndex === seatIndex)
  return player && canAct(player) ? seatIndex : null
}
