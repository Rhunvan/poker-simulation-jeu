import type { ShowdownResult, HandHistoryEntry } from '../engine/core/types'

interface HistoryPanelProps {
  entries: HandHistoryEntry[]
  showdown: ShowdownResult | null
  currencyLabel: string
  playerNames: Record<string, string>
}

export function HistoryPanel({ entries, showdown, currencyLabel, playerNames }: HistoryPanelProps) {
  return (
    <aside className="history-panel">
      <div className="history-header">
        <div>
          <p className="eyebrow">Live log</p>
          <h2>Historique</h2>
        </div>
        <span className="history-count">{entries.length}</span>
      </div>

      <div className="history-list">
        {entries.length === 0 ? (
          <p className="empty-history">Aucune action enregistree pour l instant.</p>
        ) : (
          entries
            .slice()
            .reverse()
            .map((entry) => (
              <div key={entry.id} className="history-entry" data-street={entry.street}>
                <span className="history-street">{entry.street}</span>
                <p>{entry.text}</p>
              </div>
            ))
        )}
      </div>

      {showdown && (
        <div className="showdown-panel">
          <h3>Abattage</h3>
          <div className="showdown-hands">
            {showdown.hands.map((hand) => (
              <div key={hand.playerId}>
                <strong>{playerNames[hand.playerId] ?? hand.playerId}</strong>
                <span>
                  {hand.category} · {hand.description}
                </span>
              </div>
            ))}
          </div>
          <div className="showdown-awards">
            {showdown.awards.map((award) => (
              <div key={award.potId}>
                <strong>{award.label}</strong>
                <span>
                  {award.amount} {currencyLabel} vers{' '}
                  {award.winnerIds.map((winnerId) => playerNames[winnerId] ?? winnerId).join(', ')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </aside>
  )
}
