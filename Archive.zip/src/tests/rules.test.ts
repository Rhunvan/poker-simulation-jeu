import { describe, expect, it } from 'vitest'

import { applyPlayerCommand, resetTableState, startNextHand } from '../engine'
import { getLegalActions } from '../engine/rules/legalActions'
import { makeConfig, getTestProfiles } from './testUtils'

describe('betting rules', () => {
  it('offers legal preflop actions in the expected order', () => {
    const state = resetTableState(makeConfig({ maxSeats: 3 }), getTestProfiles(2), 42)
    const legal = getLegalActions(state, 'hero')

    expect(legal?.options.map((option) => option.kind)).toEqual(['fold', 'call', 'raise', 'all-in'])
  })

  it('enforces the minimum raise based on the last full raise', () => {
    const state = resetTableState(makeConfig({ maxSeats: 3 }), getTestProfiles(2), 42)
    const afterOpen = applyPlayerCommand(state, 'hero', { kind: 'raise', total: 50 })
    const nextActorId = afterOpen.currentActorId
    const legal = nextActorId ? getLegalActions(afterOpen, nextActorId) : null

    expect(legal?.minRaiseTo).toBe(80)
  })

  it('does not reopen action after an incomplete all-in raise', () => {
    const state = resetTableState(makeConfig({ maxSeats: 3 }), getTestProfiles(2), 42)
    const smallBlind = state.players.find((player) => player.seatIndex === 1)
    if (!smallBlind) {
      throw new Error('Missing small blind')
    }
    smallBlind.stack = 60

    const afterOpen = applyPlayerCommand(state, 'hero', { kind: 'raise', total: 50 })
    const afterShortJam = applyPlayerCommand(afterOpen, afterOpen.currentActorId!, { kind: 'all-in' })
    const afterCall = applyPlayerCommand(afterShortJam, afterShortJam.currentActorId!, { kind: 'call' })
    const legal = getLegalActions(afterCall, 'hero')

    expect(legal?.options.map((option) => option.kind)).toEqual(['fold', 'call'])
  })

  it('uses correct heads-up blind order and rotates the button', () => {
    const state = resetTableState(makeConfig({ maxSeats: 2 }), getTestProfiles(1), 42)
    expect(state.dealerSeatIndex).toBe(0)
    expect(state.smallBlindSeatIndex).toBe(0)
    expect(state.bigBlindSeatIndex).toBe(1)

    const finished = applyPlayerCommand(state, 'hero', { kind: 'fold' })
    const nextHand = startNextHand(finished, finished.sessionElapsedMs)

    expect(nextHand.dealerSeatIndex).toBe(1)
    expect(nextHand.smallBlindSeatIndex).toBe(1)
    expect(nextHand.bigBlindSeatIndex).toBe(0)
  })

  it('rotates the dealer button correctly in three handed play', () => {
    const state = resetTableState(makeConfig({ maxSeats: 3 }), getTestProfiles(2), 42)
    const heroFolded = applyPlayerCommand(state, 'hero', { kind: 'fold' })
    const handFinished = applyPlayerCommand(heroFolded, heroFolded.currentActorId!, { kind: 'fold' })
    const nextHand = startNextHand(handFinished, handFinished.sessionElapsedMs)

    expect(nextHand.dealerSeatIndex).toBe(1)
  })

  it('draws opponent seats on reset while keeping them stable between hands', () => {
    const config = makeConfig({ maxSeats: 8 })
    const firstState = resetTableState(config, getTestProfiles(7), 42)
    const secondState = resetTableState(config, getTestProfiles(7), 99)

    const firstSeatMap = Object.fromEntries(firstState.players.map((player) => [player.id, player.seatIndex]))
    const secondSeatMap = Object.fromEntries(secondState.players.map((player) => [player.id, player.seatIndex]))

    expect(firstSeatMap.hero).toBe(0)
    expect(secondSeatMap.hero).toBe(0)
    expect(new Set(Object.values(firstSeatMap)).size).toBe(8)
    expect(firstSeatMap).not.toEqual(secondSeatMap)

    const threeHanded = resetTableState(makeConfig({ maxSeats: 3 }), getTestProfiles(2), 42)
    const threeHandedSeatMap = Object.fromEntries(threeHanded.players.map((player) => [player.id, player.seatIndex]))
    const heroFolded = applyPlayerCommand(threeHanded, 'hero', { kind: 'fold' })
    const afterSecondFold = applyPlayerCommand(heroFolded, heroFolded.currentActorId!, { kind: 'fold' })
    const nextHand = startNextHand(afterSecondFold, afterSecondFold.sessionElapsedMs)
    const nextHandSeatMap = Object.fromEntries(nextHand.players.map((player) => [player.id, player.seatIndex]))

    expect(nextHandSeatMap).toEqual(threeHandedSeatMap)
  })
})
